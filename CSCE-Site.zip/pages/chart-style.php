<style>
    .chart {
        background-color: rgb(229, 227, 215);
        /* padding: 20px; */
        border-style: solid;
        border-width: 2px;
        border-color: black;
        border-radius: 10px;
        /* margin: 20px; */
    }

    .chartarea {
        background-color: rgb(48, 46, 48);
        /* padding: 5px; */
        border-style: solid;
        border-width: 2px;
        border-color: black;
        /* margin: 10px; */
    }

    .StationflexContainer {
        display: flex;
        flex-direction: row;
        background-color: wheat;
        /* padding-bottom: 10px; */
        padding-right: 10px;
    }

    .StationflexContainer div {
        flex: 1;
        display: flex;
        background-color: wheat;
        /* padding-bottom: 10px; */
        padding-right: 10px;
        margin-bottom: 10px;
        margin-left: 20px;
    }
    .verticalStack{
        display: block;
    }
</style>
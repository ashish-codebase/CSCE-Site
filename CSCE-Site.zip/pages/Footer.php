<footer>
    <div class="navFlex bg60-2">
        <div class="navLink"><a href="https://parallel41-dev.web.app/#/documentation" target="_blank">Credits</a></div>
        <div class="navLink"><a href="https://hprcc.unl.edu/" target="_blank">Data Sources</a></div>
        <div class="navLink"><a href="https://github.com/ashish-codebase/ashish-codebase.github.io" target="_blank">Source Code @ Github</a></div>
    </div>
</footer>